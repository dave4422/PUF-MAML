import torch
from config import PATH
from torch.utils.data import DataLoader
from few_shot.models import FewShotClassifierPUF
from few_shot.datasets import RoPUF
from few_shot.core import NShotTaskSampler, create_nshot_task_label, EvaluateFewShot
from few_shot.maml import meta_gradient_step
from torch import nn
challenge_size = 128
meta_batch_size = 60

#n = 10
k = 1
q = 1

test_board = 'D222399'
eval_batches = 1000
param_str = 'roPUF_order=2_n=90_k=1_metabatch=75_train_steps=50_val_steps=10'


assert torch.cuda.is_available()
#TODO change to cuda
device = torch.device('cuda')





def prepare_meta_batch(n, k, q, meta_batch_size):
    def prepare_meta_batch_(batch):
        x, y = batch

        #print(batch.dim)
        #print(x.shape)
        # Reshape to `meta_batch_size` number of tasks. Each task contains
        # n*k support samples to train the fast model on and q*k query samples to
        # evaluate the fast model on and generate meta-gradients
        #print(x.shape)
        #TODO is this correct?
        x = x.reshape(meta_batch_size, n + q, x.shape[-1])
        # Move to device
        x = x.float().to(device)

        #print(x)
        y = y.reshape(meta_batch_size, n + q, 1)
        y = y.float().to(device)
        #print(x.shape)
        #print(y.reshape(meta_batch_size, n*k + q*k, 1).shape)
        # Create label
        #y = create_nshot_task_label(k, q).cuda().repeat(meta_batch_size)
        return x, y

    return prepare_meta_batch_

data = RoPUF('test_untouched',challenge_size,test_board,False)



model = FewShotClassifierPUF(in_features = challenge_size)
model.load_state_dict(torch.load(PATH + f'/models/maml2/{param_str}.pth'))
model.to(device)
model.eval()



meta_optimiser = torch.optim.Adam(model.parameters(), lr=0.001)
# TODO change to nn.BCELoss().to(device)  ??
loss_fn =  nn.BCELoss().to(device)
for n in [0,1,5,10,15,20,25,50,70,90]:
    data_taskloader = DataLoader(
        data,
        batch_sampler=NShotTaskSampler(data, eval_batches, n=n, k=k, q=q,
                                       num_tasks=1),
        num_workers=8
    )

    sum = 0
    for batch_index, batch in enumerate(data_taskloader):
        x, y = prepare_meta_batch(n,k,q,1)(batch)
        #print(batch_index)
        loss, y_pred = meta_gradient_step(
            model,
            meta_optimiser,
            loss_fn,
            x,
            y,
            n_shot=n,
            k_way=k,
            q_queries=q,
            train=False,
            order=2,
            inner_train_steps=40,
            inner_lr=0.01,
            device=device,
        )

    #do something
    #print(y_pred)
    #print(y)
        y = y[:,-q:,:]
        #print(y.item() == y_pred.item())
        #print(y_pred.item())
        #print(y.item())
        sum += (y.item() == y_pred.item())
        #print(sum)
    print(n)

    print(sum/eval_batches)
    #print('here')
#print('here2')

#print('here3')
